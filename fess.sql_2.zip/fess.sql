--
-- Database: `fess`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `faculty_name` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `dept` enum('Information Technology','Computer','Electronics&comm','Mechanical','Electrical','Civil','Science&Humanities') NOT NULL,
  `sem` enum('Semester One','Semester Two','Semester Three','Semester Four','Semester Five','Semester Six','Semester Seven','Semester Eight') NOT NULL,
  `stat` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `faculty_name`, `subject`, `dept`, `sem`, `stat`) VALUES
(51, 'teacher one', 'sub one', 'Computer', 'Semester One', 0),
(52, 'pinkal shah', 'IOT', 'Computer', 'Semester Two', 0),
(53, 'Keyur', 'CN', 'Computer', 'Semester Three', 0),
(54, 'Digvijay', 'INS', 'Computer', 'Semester Four', 0),
(55, 'Modi', 'BJP', 'Computer', 'Semester Five', 0),
(56, 'Tom Cruise', 'Action', 'Computer', 'Semester Six', 0),
(57, 'Shahrukh', 'Romance', 'Computer', 'Semester Seven', 0),
(58, 'random', 'data', 'Computer', 'Semester Eight', 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `feedback_id` int(11) NOT NULL,
  `enrollment` bigint(12) NOT NULL,
  `faculty_name` varchar(20) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `dept` enum('Information Technology','Computer','Electronics&comm','Mechanical','Electrical','Civil','Science&Humanities') NOT NULL,
  `sem` enum('Semester One','Semester Two','Semester Three','Semester Four','Semester Five','Semester Six','Semester Seven','Semester Eight') NOT NULL,
  `Timeliness` float(10,0) NOT NULL,
  `Effectiveness` float(10,0) NOT NULL,
  `Control_and_Attitude` float(10,0) NOT NULL,
  `Avg_Total` float(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hod`
--

CREATE TABLE `hod` (
  `id` int(11) NOT NULL,
  `hod_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `dept` enum('Information Technology','Computer','Electronics&comm','Mechanical','Electrical','Civil','Science&Humanities') NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hod`
--

INSERT INTO `hod` (`id`, `hod_name`, `password`, `dept`, `email`, `phone`) VALUES
(1, 'Kalyani Madam', '81dc9bdb52d04dc20036dbd8313ed055', 'Information Technology', 'Kalyanimadam@gmail.com', 32413123),
(2, 'kishori madam', '81dc9bdb52d04dc20036dbd8313ed055', 'Computer', 'kishori@gmail.com', 12341231),
(3, 'mech hod', '81dc9bdb52d04dc20036dbd8313ed055', 'Mechanical', 'mechone@xyz.com', 635234),
(4, 'ec hod', '81dc9bdb52d04dc20036dbd8313ed055', 'Electronics&comm', 'ec@hod.com', 987987999),
(5, 'civil hod', '81dc9bdb52d04dc20036dbd8313ed055', 'Civil', 'civil@hod.com', 987987654);

-- --------------------------------------------------------

--
-- Table structure for table `principal`
--

CREATE TABLE `principal` (
  `id` int(11) NOT NULL,
  `principal_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `principal`
--

INSERT INTO `principal` (`id`, `principal_name`, `password`, `email`, `phone`) VALUES
(1, 'master access', '81dc9bdb52d04dc20036dbd8313ed055', 'Principal@mail.com', 987987987);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `enrollment` bigint(12) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `dept` enum('Information Technology','Computer','Electronics&comm','Mechanical','Electrical','Civil','Science&Humanities') NOT NULL,
  `sem` enum('Semester One','Semester Two','Semester Three','Semester Four','Semester Five','Semester Six','Semester Seven','Semester Eight') NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `rating_stat` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`enrollment`, `student_name`, `dept`, `sem`, `password`, `email`, `phone`, `rating_stat`) VALUES
(0, '', 'Computer', '', 'd41d8cd98f00b204e9800998ecf8427e', '', 0, 0),
(140500109524, 'Patel Jil J.', 'Computer', 'Semester Six', 'df990c350281bc345014ab4a2fa0b4b1', 'abc@xyz.com', 123, 0),
(140500109534, 'Shah Nishit H.', 'Computer', 'Semester Six', '565bb654c310037f240f57f497b1c08f', 'abc2@xyz.com', 234, 0),
(150503109518, 'Patel Dhrmendra R.', 'Computer', 'Semester Six', 'c408d5938746e8e26de8a57218055cb4', 'abc3@xyz.com', 345, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_faculty` (`faculty_name`,`subject`,`sem`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `hod`
--
ALTER TABLE `hod`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_hod_id` (`email`,`phone`);

--
-- Indexes for table `principal`
--
ALTER TABLE `principal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD UNIQUE KEY `enrollment` (`enrollment`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `hod`
--
ALTER TABLE `hod`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `principal`
--
ALTER TABLE `principal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
